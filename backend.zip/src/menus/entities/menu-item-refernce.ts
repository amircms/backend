import { PrimaryGeneratedColumn, Column, OneToMany, ManyToOne } from 'typeorm';
import { MenuItemEntity } from '../../menu-items/entities/menu-item.entity';

export class MenuItemReference extends MenuItemEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  order: string;

  @OneToMany(() => MenuItemReference, (item) => item.parent)
  children: MenuItemReference[];

  @ManyToOne(() => MenuItemReference, (item) => item.children, {
    nullable: true,
  })
  parent: MenuItemReference;
}
