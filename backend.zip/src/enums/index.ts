export enum PageStatusEnum {
  PUBLISHED = 'published',
  DRAFT = 'draft',
}
