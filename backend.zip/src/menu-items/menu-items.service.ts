import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { CreateMenuItemDto } from './dto/create-menu-item.dto';
import { UpdateMenuItemDto } from './dto/update-menu-item.dto';
import { ParamsDto } from './dto/params.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { MenuItemEntity } from './entities/menu-item.entity';
import { PageEntity } from '../pages/entities/page.entity';
import { Repository } from 'typeorm';
import { PagesService } from '../pages/pages.service';
import { MenusService } from '../menus/menus.service';

@Injectable()
export class MenuItemsService {
  constructor(
    @InjectRepository(MenuItemEntity)
    private readonly menuItemRepository: Repository<MenuItemEntity>,
    private readonly menuService: MenusService,
    private readonly pageService: PagesService,
  ) {}
  async create(dto: CreateMenuItemDto) {
    const menu = await this.menuService.findById(dto.menuId);
    if (!menu) {
      throw new HttpException('Menu not found', HttpStatus.NOT_FOUND);
    }

    let page: PageEntity | undefined;
    if (dto.pageId) {
      page = await this.pageService.findById(dto.pageId);
      if (!page) {
        throw new HttpException('Page not found', HttpStatus.NOT_FOUND);
      }
    }

    let parent: MenuItemEntity | undefined;
    if (dto.parentId) {
      parent = await this.menuItemRepository.findOneBy({ id: dto.parentId });
      if (!parent) {
        throw new HttpException(
          'Parent menu item not found',
          HttpStatus.NOT_FOUND,
        );
      }
    }

    const item = this.menuItemRepository.create({
      ...dto,
      menu,
      page,
      parent,
    });

    return await this.menuItemRepository.save(item);
  }

  async findAll() {
    return await this.menuItemRepository.find({
      relations: ['menu', 'page', 'parent', 'children'],
      order: { order: 'ASC' },
    });
  }

  async findById(id: ParamsDto['id']) {
    const item = await this.menuItemRepository.findOne({
      where: { id },
      relations: ['menu', 'page', 'parent', 'children'],
    });

    if (!item) {
      throw new HttpException('Menu item not found', HttpStatus.NOT_FOUND);
    }

    return item;
  }

  async updateById(id: ParamsDto['id'], dto: UpdateMenuItemDto) {
    const item = await this.findById(id);

    if (dto.menuId) {
      const menu = await this.menuService.findById(dto.menuId);
      if (!menu) {
        throw new HttpException('Menu not found', HttpStatus.NOT_FOUND);
      }
      item.menu = menu;
    }

    if (dto.pageId) {
      const page = await this.pageService.findById(dto.pageId);
      if (!page) {
        throw new HttpException('Page not found', HttpStatus.NOT_FOUND);
      }
      item.page = page;
    }

    if (dto.parentId) {
      const parent = await this.menuItemRepository.findOneBy({
        id: dto.parentId,
      });
      if (!parent) {
        throw new HttpException(
          'Parent menu item not found',
          HttpStatus.NOT_FOUND,
        );
      }
      item.parent = parent;
    }

    Object.assign(item, dto);
    return await this.menuItemRepository.save(item);
  }

  async deleteById(id: ParamsDto['id']) {
    const item = await this.findById(id);
    return await this.menuItemRepository.delete(item);
  }
}
